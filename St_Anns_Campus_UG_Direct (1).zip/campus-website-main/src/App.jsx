import { useState } from "react";

import campusMap from "./assets/campus-map.jpg";
import collegeLogo from "./assets/st_anns_guide_logo.svg";


function App() {
  const [currentPage, setCurrentPage] = useState("home");

  const [pageHistory, setPageHistory] = useState([]);

  function navigateTo(nextPage) {
    setPageHistory((previousHistory) => [...previousHistory, currentPage]);

    setCurrentPage(nextPage);
  }

  function goBack() {
    const previousPage = pageHistory[pageHistory.length - 1];

    if (!previousPage) {
      return;
    }

    setCurrentPage(previousPage);

    setPageHistory((previousHistory) => previousHistory.slice(0, -1));
  }

  function Navbar() {
    return (
      <header className="navbar">
        {currentPage !== "home" && (
          <button className="navbar-back" onClick={goBack} aria-label="Go back">
            <svg
              viewBox="0 0 24 24"
              aria-hidden="true"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M19 12H5" />
              <path d="M11 18L5 12L11 6" />
            </svg>
          </button>
        )}

        <span className="navbar-title">Smart Campus Navigation</span>
      </header>
    );
  }

  /* =========================================================
     CAMPUS MAP
  ========================================================= */

  if (currentPage === "campus-map") {
    return (
      <>
        <Navbar />

        <main className="campus-map-page">
          <p className="college-name">St. Ann's College for Women</p>

          <section className="campus-map-content">
            <h1>Campus Map</h1>

            <p className="page-description">
              Tap the Undergraduate Block to open your navigation webpage.
            </p>

            <div className="map-container">
              <img
                src={campusMap}
                alt="St. Ann's College campus map"
                className="campus-map-image"
              />

              <button
                className="ug-map-hotspot"
                onClick={() => {
                  // Replace this path with your own webpage when you add it.
                  window.location.href = "/stanns-guide/index.html";
                }}
                aria-label="Open UG Block"
              ></button>
            </div>
          </section>
        </main>
      </>
    );
  }

  /* =========================================================
     HOME
  ========================================================= */

  return (
    <>
      <Navbar />

      <main className="home-page minimal-home-page">
        <section className="minimal-home-content">
          <img
            src={collegeLogo}
            alt="St. Ann's College for Women logo"
            className="minimal-home-logo"
          />

          <button
            className="start-navigation-button"
            onClick={() => navigateTo("campus-map")}
          >
            Start Navigation
          </button>
        </section>
      </main>
    </>
  );
}

export default App;
